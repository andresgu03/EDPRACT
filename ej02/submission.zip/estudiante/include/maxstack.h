/**
 * @file maxstack.h
 * @brief  Archivo de especificación del TDA MaxStack
 * @author
 */
#include <queue>
#include <ostream>

using namespace std ;

struct element{
    int value ;
    int maximum;
    // operator << overload.
    friend ostream & operator<<(std::ostream& os , const element obj);
};

class MaxStack{
private :
    queue<element> q ;
public :
    MaxStack() {};

    MaxStack(const MaxStack & otro) ;

    MaxStack & operator= ( const MaxStack & otro) ;

    element top () ;

    void push(int val);

    void pop () ;

    bool empty(){ return (q.empty());} ;

    int size(){ return (q.size()) ; } ;

    void swap(MaxStack & x ){q.swap(x.q) ;} ;
};
#ifndef __LETTERS_BAG_H__
#define __LETTERS_BAG_H__

#include <cstdlib>
#include <ctime>
#include <vector>
#include "bag.h"
#include "letters_set.h"

/**
 * @brief TDA LettersBag
 *
 * Este TDA almacena un conjunto de chars utilizado en el juego de letras.
 * La estructura de datos subyacente es una lista de chars.
 */

class LettersBag {

private:
    Bag <char> letters;

public:
    // Constructor por defecto (NO es necesario declararlo - se llama implícitamente al de Bag<char>)
    LettersBag() = default;

    // Constructor
    LettersBag(const LettersSet & letterSet);

    // Extrae varias letras de forma aleatoria de la bolsa
    std::vector<char> extractLetters(int num);

    // Operador de asignación
    LettersBag& operator=(const LettersBag & other);

    //*******************
    // Métodos INLINE
    //*******************

    // Introduce una letra en la bolsa (INLINE)
    inline void insertLetter(const char & I) {this->letters.add(I);};

    // Extrae una letra de forma aleatoria de la bolsa (INLINE)
    inline char extractLetter() {return this->letters.get();};

    // Borra los elementos de la bolsa (INLINE)
    inline void clear() {this->letters.clear();};

    // Devuelve el tamaño de la bolsa (INLINE)
    inline unsigned int size() const {return this->letters.size();};

};

#endif

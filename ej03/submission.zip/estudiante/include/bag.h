#ifndef __BAG_H__
#define __BAG_H__

#include <cstdlib>
#include <ctime>
#include <vector>

/**
 *  \brief TDA abstracto Bolsa
 *
 *  Este TDA abstracto nos permite trabajar con una colección de elementos que
 *  permite la extracción de elementos de forma aleatoria sin reemplazamiento
 */

template <class T>
class Bag {

private:
    std::vector<T> v;

public:
    // Constructor por defecto (NO es necesario declararlo - se llama implícitamente al de <vector>)
    Bag<T>() = default;

    // Constructor de copia
    Bag<T>(const Bag<T>& other)
    {
        this->v(other.v);
    }

    void add(const T& element)
    {
        this->v.push_back(element);
    }

    T get(){
        int index = (rand() % this->size());

        T elem = this->v.at(index);
        this->v.at(index) = this->v.back();
        this->v.pop_back();

        return elem;
    }

    void clear(){
        this->v.clear();
    }

    unsigned int size() const{
        return this->v.size();
    }

    bool empty(){
        return this->v.empty();
    }

    const Bag<T>& operator=(const Bag<T>& other){
        this->v = other.v;
        return *this;
    }

};

#endif
